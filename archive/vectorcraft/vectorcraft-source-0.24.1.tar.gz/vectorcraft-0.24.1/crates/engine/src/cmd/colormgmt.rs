//! Colour management: Edit → Color Settings / Assign Profile, document colour mode conversion
//! through the CMS, gamut checks, View → Proof Setup / Proof Colors / Overprint Preview, the
//! Separations Preview panel, Overprint Black and spot swatches.
//!
//! Colour settings and the proof view are process-wide (`vectorcraft_color::cms::active`,
//! `vectorcraft_render::proof::view`). A document's assigned profiles are stored in
//! `Document::color_profiles` (files before format v3: `Document.unknown["colorProfiles"]`) and
//! become active when assigned.

use std::collections::BTreeMap;
use std::sync::Arc;

use serde_json::{Value, json};
use vectorcraft_color::cms::{self, ColorSettings, Intent, Model, ProofTarget};
use vectorcraft_color::recolor::Neutral;
use vectorcraft_color::{Color, Paint};
use vectorcraft_doc::ColorMode;
use vectorcraft_render::proof;

#[cfg(not(target_arch = "wasm32"))]
use super::EngineError;
use super::{CommandSpec, Result, Session, always, bad, cmd, color_value, has_doc, switch_or, targets, text_param};

/// `Document.unknown` key under which files before format v3 kept the assigned profiles (migrated
/// to `Document::color_profiles` on load).
pub const PROFILES_KEY: &str = vectorcraft_doc::profiles::LEGACY_PROFILES_KEY;

pub fn specs() -> Vec<CommandSpec> {
    vec![
        cmd!(
            "edit.colorSettings",
            "Color Settings…",
            ["Edit"],
            Some("Cmd+Shift+K"),
            "{rgb?: profile, cmyk?: profile, intent?: \"perceptual\"|\"relative\"|\"saturation\"|\"absolute\", bpc?: bool} set the working spaces → {rgb, cmyk, intent, bpc, profiles: [{name, kind, builtin}]}. The desktop app and vectorcraft-cli keep them in `Color Settings.json` next to the preferences and use them again at the next start (not with VECTORCRAFT_NO_PREFS); saved settings naming a profile that is gone leave the defaults",
            always,
            color_settings
        ),
        cmd!(
            "color.loadProfile",
            "Load Color Profile…",
            [],
            None,
            "{path: .icc/.icm file of at most 32 MB} register an ICC profile (native only). The desktop app and vectorcraft-cli keep a copy of the file in the `Color Profiles` folder next to the preferences and register it again at every start (not with VECTORCRAFT_NO_PREFS, or in a confined `mcp --automation-*-root` server: there it lasts until the process ends) → {name, kind, remembered: whether a copy was kept}",
            always,
            load_profile
        ),
        cmd!(
            "color.removeProfile",
            "Remove Color Profile…",
            [],
            None,
            "{name} forget a profile color.loadProfile loaded, and the copy kept of it (built-in profiles and the working spaces stay) → {removed: name}",
            always,
            remove_profile
        ),
        cmd!(
            "edit.assignProfile",
            "Assign Profile…",
            ["Edit"],
            None,
            "{rgb?: profile|null, cmyk?: profile|null} tag the document with profiles (colour numbers are kept) → {rgb, cmyk}",
            has_doc,
            assign_profile
        ),
        cmd!(
            "object.convertDocumentColorMode",
            "Convert Document Color Mode",
            [],
            None,
            "{…as file.documentColorMode} same as file.documentColorMode: {mode: \"cmyk\"|\"rgb\", convert?: true, intent?, grays?} → {changed} (an alias kept for older scripts; the command palette leaves it out)",
            has_doc,
            convert_mode
        ),
        cmd!(
            query "color.convert",
            "Convert Color",
            [],
            None,
            "{color (#rrggbbaa and #rgba are refused), to: \"rgb\"|\"cmyk\"|\"gray\"|\"lab\", intent?} → {model, values, hex, lab: [L,a,b], outOfGamut, deltaE}",
            always,
            convert_color
        ),
        cmd!(
            query "color.gamutCheck",
            "Gamut Warning",
            [],
            None,
            "{ids?|id?, colors?: [color] (#rrggbbaa and #rgba are refused)} colours that can't be printed in the working CMYK (selection, or the whole document when nothing is selected) → {checked, outOfGamut: [{hex, deltaE, count}]}",
            has_doc,
            gamut_check
        ),
        cmd!(
            query "view.proofSetup",
            "Proof Setup",
            ["View", "Proof Setup"],
            None,
            "{target?: \"workingCmyk\"|\"cmyk:<profile>\"|\"legacyMacRgb\"|\"srgb\"|\"monitorRgb\"|\"protanopia\"|\"deuteranopia\"|\"tritanopia\", intent?, simulatePaper?, proof?: bool (also turn Proof Colors on)} → proof state",
            always,
            proof_setup
        ),
        cmd!(query "view.proofColors", "Proof Colors", ["View"], None, "{on?: bool (default: toggle)} → proof state", always, |s, p| {
            toggle_view(s, p, "view.proofColors", |v, on| v.proof_colors = on.unwrap_or(!v.proof_colors))
        }),
        cmd!(
            query "view.overprintPreview",
            "Overprint Preview",
            ["View"],
            Some("Cmd+Alt+Shift+Y"),
            "{on?: bool (default: toggle)} → proof state",
            always,
            |s, p| toggle_view(s, p, "view.overprintPreview", |v, on| v.overprint = on.unwrap_or(!v.overprint))
        ),
        cmd!(
            query "view.separationsPreview",
            "Separations Preview",
            [],
            None,
            "{on?: bool, plates?: [names], toggle?: plate, only?: plate} Separations Preview: show the chosen plates (one plate = greyscale ink coverage) → {on, plates: [{name, spot, visible, rgb}]}",
            always,
            separations
        ),
        cmd!(query "color.plates", "Plates", [], None, "{} → {on, plates: [{name, spot, visible, rgb}]}", always, |s, _| Ok(plates_json(s))),
        cmd!(
            "edit.colors.overprintBlack",
            "Overprint Black…",
            ["Edit", "Edit Colors"],
            None,
            "{remove?: false, percentage?: 100, fill?: true, stroke?: true, includeCmyBlacks?: false, includeSpotBlacks?: false, ids?} make the black fills and/or strokes of the selection (or ids; groups: their contents; type: its characters) overprint, or stop (remove). Black: K ≥ percentage with no C, M or Y (any with includeCmyBlacks), not linked to a spot swatch (unless includeSpotBlacks); a gradient is black when every stop is → {changed: objects}",
            has_doc,
            super::overprint::overprint_black
        ),
        cmd!(
            "swatch.setSpot",
            "Spot Color",
            [],
            None,
            "{name, spot?: true} make a swatch a spot colour (prints on its own plate; spot swatches are global) → {name, spot}",
            has_doc,
            set_spot
        ),
    ]
}

fn intent_param(p: &Value, cmd: &str) -> Result<Option<Intent>> {
    match text_param(p, "intent", cmd)? {
        None => Ok(None),
        Some(i) => Intent::parse(i).map(Some).ok_or_else(|| bad(cmd, format!("unknown intent `{i}`"))),
    }
}

/// The true or false `p` gives for `key`, or `None` when `p` leaves it out or gives null. Any other
/// value is an error, as [`switch_or`] reads it.
fn on_param(p: &Value, key: &str, cmd: &str) -> Result<Option<bool>> {
    if p.get(key).is_none_or(Value::is_null) {
        return Ok(None);
    }
    switch_or(p, key, false, cmd).map(Some)
}

fn settings_json(st: &ColorSettings) -> Value {
    json!({
        "rgb": st.rgb,
        "cmyk": st.cmyk,
        "intent": st.intent.id(),
        "bpc": st.bpc,
        "profiles": cms::profiles().iter().map(|p| json!({"name": p.name, "kind": p.kind, "builtin": p.builtin})).collect::<Vec<_>>(),
    })
}

/// Colour settings/proof changes don't edit the document, but the canvas must redraw: bump the
/// revisions (which never mark documents dirty).
fn touch_all(s: &mut Session) {
    for d in &mut s.docs {
        d.revision += 1;
    }
}

fn color_settings(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "edit.colorSettings";
    let mut st = cms::active_settings();
    let before = st.clone();
    if let Some(v) = text_param(p, "rgb", C)? {
        st.rgb = cms::canonical_name(v).to_string();
    }
    if let Some(v) = text_param(p, "cmyk", C)? {
        st.cmyk = cms::canonical_name(v).to_string();
    }
    if let Some(i) = intent_param(p, C)? {
        st.intent = i;
    }
    st.bpc = switch_or(p, "bpc", st.bpc, C)?;
    if st != before {
        cms::set_active(&st).map_err(|e| bad(C, e.to_string()))?;
        // Saved for the next start when the app attached a settings file (#6335).
        s.store_color_settings(&st);
        touch_all(s);
    }
    Ok(settings_json(&st))
}

#[cfg(not(target_arch = "wasm32"))]
fn load_profile(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "color.loadProfile";
    let path = text_param(p, "path", C)?.ok_or_else(|| bad(C, "missing `path`"))?;
    crate::file_access::check_read(path).map_err(EngineError::Other)?;
    let bytes = crate::store::read_capped(std::path::Path::new(path), crate::store::MAX_PROFILE_FILE).map_err(|e| bad(C, format!("{path}: {e}")))?;
    let info = cms::register_icc(&bytes, None).map_err(|e| bad(C, e.to_string()))?;
    // The bytes are kept, not the path: the file may move or go away.
    let remembered = s.store_profile(&info.name, &bytes);
    // A new file of a working space: the active settings still hold the old one.
    let working = cms::active_settings();
    if working.rgb == info.name || working.cmyk == info.name {
        cms::set_active(&working).map_err(|e| bad(C, e.to_string()))?;
        touch_all(s);
    }
    Ok(json!({"name": info.name, "kind": info.kind, "remembered": remembered}))
}

/// Forget a profile `color.loadProfile` loaded, and the copy that is kept of it.
fn remove_profile(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "color.removeProfile";
    let name = text_param(p, "name", C)?.ok_or_else(|| bad(C, "missing `name`"))?;
    let info = cms::profiles().into_iter().find(|i| i.name == name).ok_or_else(|| bad(C, format!("no profile named `{name}`")))?;
    if info.builtin {
        return Err(bad(C, format!("`{name}` is a built-in profile and stays")));
    }
    let working = cms::active_settings();
    if working.rgb == name || working.cmyk == name {
        return Err(bad(C, format!("`{name}` is a working space: choose another with edit.colorSettings first")));
    }
    if !cms::unregister_icc(&info.name) {
        return Err(bad(C, format!("no profile named `{name}`")));
    }
    s.unstore_profile(&info.name);
    touch_all(s);
    Ok(json!({"removed": info.name}))
}

#[cfg(target_arch = "wasm32")]
fn load_profile(_: &mut Session, _: &Value) -> Result<Value> {
    Err(bad("color.loadProfile", "loading profiles from disk isn't available in the browser"))
}

/// The document's assigned profiles (`None` = working space).
pub fn doc_profiles(d: &vectorcraft_doc::Document) -> (Option<String>, Option<String>) {
    let get = |n: &Option<String>| n.as_deref().map(|n| cms::canonical_name(n).to_string());
    (get(&d.color_profiles.rgb), get(&d.color_profiles.cmyk))
}

fn assign_profile(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "edit.assignProfile";
    let (mut rgb, mut cmyk) = doc_profiles(&s.doc()?.doc);
    let pick = |key: &str, cur: &mut Option<String>, kind: cms::ProfileKind| -> Result<bool> {
        match p.get(key) {
            None => Ok(false),
            Some(Value::Null) => Ok(cur.take().is_some()),
            Some(Value::String(n)) => {
                let Some(info) = cms::profile(n).filter(|k| k.kind == kind) else {
                    return Err(bad(C, format!("unknown {key} profile `{n}`")));
                };
                let changed = cur.as_deref() != Some(info.name.as_str());
                *cur = Some(info.name);
                Ok(changed)
            }
            Some(_) => Err(bad(C, format!("`{key}` must be a profile name or null"))),
        }
    };
    let changed = pick("rgb", &mut rgb, cms::ProfileKind::Rgb)? | pick("cmyk", &mut cmyk, cms::ProfileKind::Cmyk)?;
    if changed {
        let profiles = vectorcraft_doc::ColorProfiles { rgb: rgb.clone(), cmyk: cmyk.clone() };
        s.edit("Assign Profile", |d, _| {
            d.color_profiles = profiles;
            Ok(())
        })?;
        let mut st = cms::active_settings();
        if let Some(r) = &rgb {
            st.rgb = r.clone();
        }
        if let Some(c) = &cmyk {
            st.cmyk = c.clone();
        }
        cms::set_active(&st).map_err(|e| bad(C, e.to_string()))?;
        touch_all(s);
    }
    Ok(json!({"rgb": rgb, "cmyk": cmyk}))
}

/// How Document Color Mode converts neutral RGB greys (R = G = B) to CMYK (the `grays` param).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Grays {
    /// Through the CMYK profile like any colour: light grays in cyan, magenta and yellow only, darker
    /// grays in four inks, and a rich black.
    #[default]
    Profile,
    /// On the black plate only: K is the grey's ink percentage (as Convert to Grayscale and then
    /// to CMYK would give).
    Black,
}

impl Grays {
    /// The `grays` param of `cmd`: `"profile"` (default) or `"black"`.
    pub(crate) fn param(cmd: &str, p: &Value) -> Result<Self> {
        match text_param(p, "grays", cmd)?.map(str::to_ascii_lowercase).as_deref() {
            None | Some("profile") => Ok(Grays::Profile),
            Some("black") => Ok(Grays::Black),
            Some(g) => Err(bad(cmd, format!("grays must be \"profile\" or \"black\", not `{g}`"))),
        }
    }
}

/// File → Document Color Mode (`file.documentColorMode` and its alias
/// `object.convertDocumentColorMode`): set the mode and, unless `convert: false`, convert every
/// colour through the colour settings.
pub(crate) fn convert_mode(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "file.documentColorMode";
    let mode = match p.get("mode").and_then(Value::as_str).map(str::to_ascii_lowercase).as_deref() {
        Some("cmyk") => ColorMode::Cmyk,
        Some("rgb") => ColorMode::Rgb,
        _ => return Err(bad(C, "mode must be \"cmyk\" or \"rgb\"")),
    };
    let intent = intent_param(p, C)?;
    let grays = Grays::param(C, p)?;
    let convert = switch_or(p, "convert", true, C)?;
    // Choosing the mode the document already has (the checked menu item) is not an edit.
    if s.doc()?.doc.color_mode == mode {
        return Ok(json!({ "changed": 0 }));
    }
    let mut changed = 0usize;
    s.edit("Document Color Mode", |d, _| {
        changed = set_color_mode(d, mode, convert, intent, grays);
        Ok(())
    })?;
    if convert {
        if s.in_interaction() && s.batch_stash.is_none() {
            if let Some(it) = &mut s.doc_mut()?.interaction {
                it.deferred_color_mode = Some(DeferredColorMode { mode, intent, grays });
            }
        } else {
            let before = new_art_colors_before(s)?;
            convert_new_art_colors(s, mode, intent, grays)?;
            record_new_art_colors(s, before)?;
        }
    } else if s.batch_stash.is_some() || s.doc()?.undo_group.is_some() {
        let before = new_art_colors_before(s)?;
        record_new_art_colors(s, before)?;
    }
    Ok(json!({ "changed": changed }))
}

/// The validated conversion choices of the current tentative color-mode preview.
#[derive(Clone, Copy, Debug)]
pub(crate) struct DeferredColorMode {
    mode: ColorMode,
    intent: Option<Intent>,
    grays: Grays,
}

/// Complete the deferred new-art conversion before the interaction becomes an Undo step.
pub(crate) fn commit_new_art_colors(s: &mut Session) -> Result<()> {
    let pending =
        s.doc()?.interaction.as_ref().filter(|it| it.preview.is_some() && it.color_mode_paints.is_none()).and_then(|it| it.deferred_color_mode);
    if let Some(DeferredColorMode { mode, intent, grays }) = pending {
        let before = new_art_colors_before(s)?;
        convert_new_art_colors(s, mode, intent, grays)?;
        record_new_art_colors(s, before)?;
    }
    Ok(())
}

fn record_new_art_colors(s: &mut Session, before: vectorcraft_tools::PaintDefaults) -> Result<()> {
    let after = s.paint.clone();
    if before != after || s.batch_stash.is_some() || s.doc()?.undo_group.is_some() {
        let st = s.doc_mut()?;
        let slot = if let Some(it) = &mut st.interaction {
            Some(&mut it.color_mode_paints)
        } else {
            st.history.undo.last_mut().map(|e| &mut e.color_mode_paints)
        };
        if let Some(slot) = slot {
            match slot {
                Some((_, end)) => *end = after,
                slot => *slot = Some((before, after)),
            }
        }
        if st.interaction.is_none() {
            if let Some(e) = st.history.undo.last_mut() {
                e.recost_paints();
            }
            st.history.trim();
        }
    }
    Ok(())
}

fn new_art_colors_before(s: &Session) -> Result<vectorcraft_tools::PaintDefaults> {
    let st = s.doc()?;
    Ok(st.undo_group.as_ref().map(|g| &g.paint).or_else(|| st.interaction.as_ref().map(|it| &it.paint)).cloned().unwrap_or_else(|| s.paint.clone()))
}

/// Convert the fill and stroke that new art takes, and the colors of its template appearance
/// (paints and effect colors), as [`set_color_mode`] converted the active document's art. The
/// command records their original values for Undo. Previews defer this until acceptance;
/// a batch converts immediately and restores the values itself when it fails.
fn convert_new_art_colors(s: &mut Session, mode: ColorMode, intent: Option<Intent>, grays: Grays) -> Result<()> {
    let d = &s.doc()?.doc;
    let bases = global_bases(d);
    let conv = mode_converter(mode, intent, grays);
    let mut f = |col: &Color, link: proof::Link| mode_color(col, link, &bases, &conv);
    map_paint_colors(&mut s.paint.fill, &mut f);
    map_paint_colors(&mut s.paint.stroke, &mut f);
    if let Some(a) = s.paint.appearance.as_mut() {
        for it in &mut a.items {
            let paint = match it {
                vectorcraft_doc::AppearanceItem::Fill(l) => &mut l.paint,
                vectorcraft_doc::AppearanceItem::Stroke(l) => &mut l.paint,
            };
            map_paint_colors(paint, &mut f);
        }
        map_effect_colors(a, &mut f);
    }
    Ok(())
}

/// How Document Color Mode converts a color to `mode` through the color settings (`intent`,
/// default: theirs): Gray and Lab colors stay as they are; with `grays` on the black plate, an RGB
/// gray becomes K only in CMYK.
fn mode_converter(mode: ColorMode, intent: Option<Intent>, grays: Grays) -> impl Fn(&Color) -> Color {
    let c = cms::active();
    let intent = intent.unwrap_or(c.settings().intent);
    let model = if mode == ColorMode::Cmyk { Model::Cmyk } else { Model::Rgb };
    let k_only = model == Model::Cmyk && grays == Grays::Black;
    move |col: &Color| match col {
        Color::Gray { .. } | Color::Lab { .. } => *col,
        // Grey ink percentage, then K only (a Gray colour's CMYK).
        Color::Rgb { .. } if k_only && Neutral::of(col).is_some() => c.convert(&c.convert(col, Model::Gray, intent), Model::Cmyk, intent),
        _ => c.convert(col, model, intent),
    }
}

/// The name and color of each global swatch of `d`, for [`mode_color`].
fn global_bases(d: &vectorcraft_doc::Document) -> Vec<(String, Color)> {
    d.swatches_iter().filter_map(|w| Some((w.name.clone(), d.global_color(&w.name)?))).collect()
}

/// The color Document Color Mode gives `col` (swatch link `link`): a tint of a global swatch in
/// `bases` (already converted) is that swatch's color at its tint; any other color goes through
/// `conv` ([`mode_converter`]).
fn mode_color(col: &Color, link: proof::Link, bases: &[(String, Color)], conv: &dyn Fn(&Color) -> Color) -> Color {
    match link.and_then(|(name, tint)| Some((bases.iter().find(|(n, _)| n == name)?, tint))) {
        Some(((_, base), tint)) if tint < 1.0 => base.tinted(tint),
        _ => conv(col),
    }
}

/// Put `d` in color `mode` and, with `convert`, convert every color of its art (opacity masks,
/// effect colors and the series paints and label styles that graphs keep included), symbols,
/// graph designs, pattern tiles (the tile that pattern editing's Cancel puts back included),
/// graphic styles (their effects included), brushes (their art and a Hue Shift key color) and
/// swatches through the color settings (`intent`, default: theirs) → how many colors of the art
/// (opacity masks, effect colors and graphs' paints included), symbols, graph designs and pattern
/// tiles changed; the colors of graphic styles and brushes convert without being counted. Gray
/// colors stay Gray (they print on the black plate in either mode); RGB grays are colors like any
/// other and separate through the CMYK profile, unless `grays` puts them on the black plate
/// ([`mode_converter`]). Lab colors
/// (spot color definitions) are device independent and fit either mode. A tint of a global
/// swatch becomes the converted swatch's color at its tint. Document Color Mode and
/// `document.open {colorMode}` both convert this way.
pub(crate) fn set_color_mode(d: &mut vectorcraft_doc::Document, mode: ColorMode, convert: bool, intent: Option<Intent>, grays: Grays) -> usize {
    d.color_mode = mode;
    if !convert {
        return 0;
    }
    let conv = mode_converter(mode, intent, grays);
    for sw in d.swatches_iter_mut() {
        match &mut sw.paint {
            Paint::Solid { color, .. } => *color = conv(color),
            Paint::Gradient(g) => {
                for st in &mut g.gradient.stops {
                    st.color = conv(&st.color);
                }
            }
            _ => {}
        }
    }
    // Tints are their converted swatch's colour at their tint (exact ink percentages).
    let bases = global_bases(d);
    let changed = std::cell::Cell::new(0usize);
    let mut count = |col: &Color, link: proof::Link| {
        let n = mode_color(col, link, &bases, &conv);
        if n != *col {
            changed.set(changed.get() + 1);
        }
        n
    };
    let patterns = d.patterns.iter_mut().chain(d.pattern_edit.iter_mut().filter_map(|e| e.original.as_mut()));
    for a in d
        .layers
        .iter_mut()
        .chain(d.symbols.iter_mut().map(|s| &mut s.art))
        .chain(d.graph_designs.iter_mut().map(|g| &mut g.art))
        .chain(patterns.flat_map(|p| &mut p.art))
    {
        map_art_colors(Arc::make_mut(a), &mut count);
    }
    // The reply counts the colors of the document's art only, not those of the graphic styles and brushes.
    let in_art = changed.get();
    for g in &mut d.graphic_styles {
        for it in &mut g.appearance.items {
            let paint = match it {
                vectorcraft_doc::AppearanceItem::Fill(l) => &mut l.paint,
                vectorcraft_doc::AppearanceItem::Stroke(l) => &mut l.paint,
            };
            map_paint_colors(paint, &mut count);
        }
        map_effect_colors(&mut g.appearance, &mut count);
    }
    // Convert each brush's art. A Hue Shift key color takes the converted color of the art color
    // it matches (a tint of a global swatch included), so the key still matches the converted art;
    // a key that matches no art color converts on its own.
    let in_styles = changed.get();
    let mut brushes = vectorcraft_brush::library(d);
    let mut keys = false;
    for b in &mut brushes {
        let old_key = match b.kind.colorization() {
            vectorcraft_brush::Colorization::HueShift { key } => Some(key),
            _ => None,
        };
        let mut new_key = None;
        for art in b.art_mut() {
            map_art_colors(art, &mut |col: &Color, link: proof::Link| {
                let n = count(col, link);
                if new_key.is_none() && old_key.is_some_and(|k| matches_key(col, &k)) {
                    new_key = Some(n);
                }
                n
            });
        }
        let colorization = match &mut b.kind {
            vectorcraft_brush::BrushKind::Art(a) => Some(&mut a.colorization),
            vectorcraft_brush::BrushKind::Scatter(s) => Some(&mut s.colorization),
            vectorcraft_brush::BrushKind::Pattern(p) => Some(&mut p.colorization),
            vectorcraft_brush::BrushKind::Calligraphic(_) | vectorcraft_brush::BrushKind::Bristle(_) => None,
        };
        if let Some(vectorcraft_brush::Colorization::HueShift { key }) = colorization {
            let n = new_key.unwrap_or_else(|| conv(key));
            keys |= n != *key;
            *key = n;
        }
    }
    if keys || changed.get() > in_styles {
        vectorcraft_brush::store(d, &brushes);
    }
    // This pass gives tint swatches their converted swatch's color at their tint; the passes above already did the same for the art's tints.
    d.map_solid_paints(&mut |c, link, tint| match bases.iter().find(|(n, _)| Some(n) == link.as_ref()) {
        Some((_, base)) if *tint < 1.0 => {
            *c = base.tinted(*tint);
            true
        }
        _ => false,
    });
    in_art
}

/// [`proof::map_node_colors`] over `n`'s subtree, then [`map_more_colors`].
fn map_art_colors(n: &mut vectorcraft_doc::Node, f: &mut dyn FnMut(&Color, proof::Link) -> Color) {
    proof::map_node_colors(n, f);
    map_more_colors(n, f);
}

/// `f` applied to the colors in `n`'s subtree that [`proof::map_node_colors`] does not visit: the
/// effect colors ([`map_effect_colors`]), the series paints and label styles a graph keeps
/// ([`map_graph_colors`]) and the art of every opacity mask.
fn map_more_colors(n: &mut vectorcraft_doc::Node, f: &mut dyn FnMut(&Color, proof::Link) -> Color) {
    map_effect_colors(&mut n.appearance, f);
    if let Some(e) = n.extras_if_any() {
        if let Some(g) = e.graph.as_deref_mut() {
            map_graph_colors(g, f);
        }
        if let Some(mask) = e.mask.as_deref_mut() {
            map_art_colors(Arc::make_mut(&mut mask.art), f);
        }
    }
    if let Some(ch) = n.children_mut() {
        for c in ch.iter_mut().filter(|c| !c.is_ruler_guide()) {
            map_more_colors(Arc::make_mut(c), f);
        }
    }
}

/// Whether art color `c` is the Hue Shift key color `key`, with the tolerance the brush's
/// colorization matches it with.
fn matches_key(c: &Color, key: &Color) -> bool {
    c.to_rgb().iter().zip(key.to_rgb()).map(|(a, b)| (a - b).abs()).sum::<f32>() < 0.02
}

/// `f` applied to the `color` of each effect in appearance `a` (the object's effects and those of
/// each fill and stroke) that has one ([`super::params::effect_color`]). An effect that draws its
/// default color stores the new color as its own. The light colors of the 3D effects stay as they
/// are.
fn map_effect_colors(a: &mut vectorcraft_doc::Appearance, f: &mut dyn FnMut(&Color, proof::Link) -> Color) {
    let items = a.items.iter_mut().flat_map(|i| i.effects_mut().iter_mut());
    for e in a.effects.iter_mut().chain(items) {
        if !(e.params.is_object() || e.params.is_null()) {
            continue;
        }
        let Some(color) = super::params::effect_color(&e.id, &e.params) else { continue };
        let n = f(&color, None);
        if n == color {
            continue;
        }
        match &mut e.params {
            Value::Object(m) => {
                m.insert("color".into(), json!(n));
            }
            p => *p = json!({ "color": n }),
        }
    }
}

/// `f` applied to the series paints and the label styles that graph `g` keeps, which its marks and
/// labels take each time it is drawn again.
fn map_graph_colors(g: &mut vectorcraft_doc::GraphSpec, f: &mut dyn FnMut(&Color, proof::Link) -> Color) {
    for p in g.series_paints.iter_mut() {
        for paint in [&mut p.fill, &mut p.stroke].into_iter().flatten() {
            map_paint_colors(paint, f);
        }
    }
    let styles = &mut g.label_styles;
    for st in [&mut styles.values, &mut styles.categories, &mut styles.legend].into_iter().flatten() {
        map_paint_colors(&mut st.fill, f);
        map_paint_colors(&mut st.stroke, f);
    }
}

/// `f` applied to solid, gradient-stop and freeform-control colors, with any swatch link.
fn map_paint_colors(p: &mut Paint, f: &mut dyn FnMut(&Color, proof::Link) -> Color) {
    match p {
        Paint::Solid { color, swatch, tint } => *color = f(color, swatch.as_deref().map(|s| (s, *tint))),
        Paint::Gradient(g) => {
            for st in &mut g.gradient.stops {
                st.color = f(&st.color, st.swatch.as_deref().map(|s| (s, st.tint)));
            }
            if let Some(freeform) = &mut g.freeform {
                for point in &mut freeform.points {
                    point.color = f(&point.color, None);
                }
            }
        }
        _ => {}
    }
}

fn values(c: &Color) -> Vec<f32> {
    match *c {
        Color::Rgb { r, g, b } => vec![r, g, b],
        Color::Cmyk { c, m, y, k } => vec![c, m, y, k],
        Color::Gray { k } => vec![k],
        Color::Lab { l, a, b } => vec![l, a, b],
    }
}

fn convert_color(_: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "color.convert";
    let col = p.get("color").and_then(color_value).ok_or_else(|| bad(C, "missing or invalid `color`"))?;
    let c = cms::active();
    let intent = intent_param(p, C)?.unwrap_or(c.settings().intent);
    let lab = c.lab(&col);
    let (model, vals) = match text_param(p, "to", C)?.unwrap_or("rgb") {
        "rgb" => ("rgb", values(&c.convert(&col, Model::Rgb, intent))),
        "cmyk" => ("cmyk", values(&c.convert(&col, Model::Cmyk, intent))),
        "gray" | "grayscale" => ("gray", values(&c.convert(&col, Model::Gray, intent))),
        "lab" => ("lab", vec![lab.l, lab.a, lab.b]),
        other => return Err(bad(C, format!("unknown model `{other}`"))),
    };
    let de = c.gamut_error(&col);
    Ok(json!({
        "model": model,
        "values": vals,
        "hex": col.to_hex(),
        "lab": [lab.l, lab.a, lab.b],
        "outOfGamut": de > cms::GAMUT_THRESHOLD,
        "deltaE": de,
    }))
}

fn gamut_check(s: &mut Session, p: &Value) -> Result<Value> {
    let mut cols: Vec<Color> = vec![];
    let colors = p.get("colors").filter(|v| !v.is_null());
    if let Some(v) = colors.filter(|v| !v.is_array()) {
        return Err(bad("color.gamutCheck", format!("`colors` must be an array of colors, not {v}")));
    }
    if let Some(a) = colors.and_then(Value::as_array) {
        for v in a {
            cols.push(color_value(v).ok_or_else(|| bad("color.gamutCheck", format!("bad color {v}")))?);
        }
    } else {
        let st = s.doc()?;
        let ids = targets(s, p)?;
        let mut collect = |n: &vectorcraft_doc::Node| {
            let mut n = n.clone();
            proof::map_node_colors(&mut n, &mut |c, _| {
                cols.push(*c);
                *c
            });
        };
        if ids.is_empty() {
            for l in &st.doc.layers {
                collect(l);
            }
        } else {
            for id in ids {
                if let Some(n) = st.doc.node(id) {
                    collect(n);
                }
            }
        }
    }
    let c = cms::active();
    let mut out: BTreeMap<String, (f32, usize)> = BTreeMap::new();
    for col in &cols {
        let de = c.gamut_error(col);
        if de > cms::GAMUT_THRESHOLD {
            out.entry(col.to_hex()).or_insert((de, 0)).1 += 1;
        }
    }
    Ok(json!({
        "checked": cols.len(),
        "outOfGamut": out.iter().map(|(h, (de, n))| json!({"hex": h, "deltaE": de, "count": n})).collect::<Vec<_>>(),
    }))
}

fn view_json(v: &proof::ProofView) -> Value {
    json!({
        "target": v.setup.target.id(),
        "intent": v.setup.intent.id(),
        "simulatePaper": v.setup.simulate_paper,
        "proofColors": v.proof_colors,
        "overprintPreview": v.overprint,
        "separations": v.separations,
    })
}

fn proof_setup(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "view.proofSetup";
    let mut v = proof::view();
    if let Some(t) = text_param(p, "target", C)? {
        let t = ProofTarget::parse(t).ok_or_else(|| bad(C, format!("unknown proof target `{t}`")))?;
        if let ProofTarget::Cmyk(name) = &t
            && !cms::profile(name).is_some_and(|k| k.kind == cms::ProfileKind::Cmyk)
        {
            return Err(bad(C, format!("unknown CMYK profile `{name}`")));
        }
        v.setup.target = t;
    }
    if let Some(i) = intent_param(p, C)? {
        v.setup.intent = i;
    }
    v.setup.simulate_paper = switch_or(p, "simulatePaper", v.setup.simulate_paper, C)?;
    if let Some(on) = on_param(p, "proof", C)? {
        v.proof_colors = on;
    }
    proof::set_view(v.clone());
    touch_all(s);
    Ok(view_json(&v))
}

fn toggle_view(s: &mut Session, p: &Value, cmd: &str, f: impl FnOnce(&mut proof::ProofView, Option<bool>)) -> Result<Value> {
    let on = on_param(p, "on", cmd)?;
    let mut v = proof::view();
    f(&mut v, on);
    proof::set_view(v.clone());
    touch_all(s);
    Ok(view_json(&v))
}

fn plates_json(s: &Session) -> Value {
    let v = proof::view();
    let plates = s.active().map(|d| proof::plates(&d.doc)).unwrap_or_default();
    json!({
        "on": v.separations.is_some(),
        "plates": plates.iter().map(|pl| json!({
            "name": pl.name,
            "spot": pl.spot,
            "visible": v.separations.as_ref().is_none_or(|vis| vis.contains(&pl.name)),
            "rgb": pl.rgb,
        })).collect::<Vec<_>>(),
    })
}

fn separations(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "view.separationsPreview";
    let mut v = proof::view();
    let all: Vec<String> = s
        .active()
        .map(|d| proof::plates(&d.doc).into_iter().map(|p| p.name).collect())
        .unwrap_or_else(|| cms::PROCESS_PLATES.iter().map(|s| s.to_string()).collect());
    let check = |n: &str| if all.iter().any(|a| a == n) { Ok(n.to_string()) } else { Err(bad(C, format!("unknown plate `{n}`"))) };
    if let Some(on) = on_param(p, "on", C)? {
        v.separations = if on { Some(v.separations.take().unwrap_or_else(|| all.clone())) } else { None };
    }
    match p.get("plates") {
        None | Some(Value::Null) => {}
        Some(Value::Array(a)) if a.iter().all(Value::is_string) => {
            v.separations = Some(a.iter().filter_map(Value::as_str).map(check).collect::<Result<Vec<_>>>()?);
        }
        Some(_) => {
            let key = "plates";
            return Err(bad(C, format!("`{key}` must be an array of these names: {}", all.join(", "))));
        }
    }
    if let Some(n) = text_param(p, "only", C)? {
        v.separations = Some(vec![check(n)?]);
    }
    if let Some(n) = text_param(p, "toggle", C)? {
        let n = check(n)?;
        let vis = v.separations.get_or_insert_with(|| all.clone());
        if let Some(i) = vis.iter().position(|x| *x == n) {
            vis.remove(i);
        } else {
            vis.push(n);
        }
    }
    proof::set_view(v);
    touch_all(s);
    Ok(plates_json(s))
}

fn set_spot(s: &mut Session, p: &Value) -> Result<Value> {
    const C: &str = "swatch.setSpot";
    let name = text_param(p, "name", C)?.ok_or_else(|| bad(C, "missing `name`"))?.to_string();
    let spot = switch_or(p, "spot", true, C)?;
    let sw = s.doc()?.doc.swatch(&name).ok_or_else(|| bad(C, format!("no swatch `{name}`")))?;
    if !matches!(sw.paint, Paint::Solid { .. }) {
        return Err(bad(C, "only solid-colour swatches can be spot colours"));
    }
    if sw.spot != spot {
        let n = name.clone();
        let colorized_ok = super::paint::check_colorized(&s.doc()?.doc).is_ok();
        s.edit("Swatch Options", |d, _| {
            if let Some(w) = d.swatch_mut(&n) {
                w.spot = spot;
                if spot {
                    w.global = true;
                }
            }
            super::paint::check_colorized_kept(colorized_ok, d).map_err(|e| bad(C, e))
        })?;
    }
    Ok(json!({"name": name, "spot": spot}))
}

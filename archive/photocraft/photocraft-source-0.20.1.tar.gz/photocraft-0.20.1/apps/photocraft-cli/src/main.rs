#![deny(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::unimplemented, clippy::todo, clippy::unreachable)]

fn main() {
    // May re-execute this process with glibc tuned to return freed document memory (#8743).
    photocraft_engine::malloc_tuning::apply();
    // `args_os`, not `args`: a non-Unicode argument (a Latin-1 file name on Linux) must reach clap,
    // not panic before anything is printed (issue #1108).
    let code = photocraft_cli::run(std::env::args_os().skip(1), &mut std::io::stdout(), &mut std::io::stderr());
    std::process::exit(code);
}

//! JPEG: decode via `zune-jpeg` (gray, YCbCr, CMYK, YCCK), encode via
//! `jpeg-encoder` (gray, RGB, CMYK). Metadata (APP0 JFIF density, APP1
//! EXIF/XMP, APP2 multi-segment ICC, APP13 Photoshop resources, APP14 Adobe) is
//! parsed by our own marker scanner so behaviour does not depend on decoder internals.
//!
//! **Resolution** (#1691) can be recorded four times; like Photoshop the first usable one of
//! these wins: the APP13 Photoshop ResolutionInfo, the XMP `tiff:` resolution, the EXIF IFD0
//! resolution, and last the JFIF density (a unit-0 JFIF density is only an aspect ratio and
//! never counts). Cameras record their resolution in EXIF only, and many tools write a default
//! 72 into JFIF, so JFIF can't outrank EXIF (see [`crate::resolution`]). On export RGB and gray
//! images carry density in JFIF; CMYK omits JFIF APP0, which is invalid for four components, and
//! carries an available density in EXIF instead.

use zune_core::bytestream::ZCursor;
use zune_core::colorspace::ColorSpace;
use zune_core::options::DecoderOptions;

use crate::Format;
use crate::error::CodecError;
use crate::fidelity::Plan;
use crate::image::{ChannelLayout, DecodeWarning, Image, Metadata, SampleType};
use crate::options::{EncodeOptions, JpegFormat, Limits};
use crate::resolution::{exif_resolution, export_exif, export_xmp, photoshop_resolution, xmp_resolution};

const F: Format = Format::Jpeg;
const EXIF_HEADER: &[u8] = b"Exif\0\0";
const XMP_HEADER: &[u8] = b"http://ns.adobe.com/xap/1.0/\0";
const ICC_HEADER: &[u8] = b"ICC_PROFILE\0";
const PHOTOSHOP_HEADER: &[u8] = b"Photoshop 3.0\0";

#[derive(Default, Debug)]
pub(crate) struct JpegMeta {
    pub icc: Option<Vec<u8>>,
    pub exif: Option<Vec<u8>>,
    pub xmp: Option<String>,
    pub dpi: Option<(f32, f32)>,
    /// The APP13 Photoshop image resource blocks (`8BIM` ...), segments joined, without the header.
    pub photoshop: Option<Vec<u8>>,
    pub adobe_transform: Option<u8>,
    /// (width, height, components) from the first SOFn.
    pub frame: Option<(u32, u32, u8)>,
}

/// Walk the marker segments up to SOS and collect metadata.
pub(crate) fn scan_metadata(b: &[u8]) -> JpegMeta {
    let mut m = JpegMeta::default();
    let mut icc_parts: Vec<(u8, u8, &[u8])> = Vec::new();
    // Photoshop splits a large resource block over consecutive APP13 segments.
    let mut photoshop: Vec<u8> = Vec::new();
    let mut jfif_dpi = None;
    let mut i = 2;
    while i + 4 <= b.len() {
        if b[i] != 0xFF {
            break;
        }
        let marker = b[i + 1];
        if marker == 0xFF {
            i += 1;
            continue;
        }
        if marker == 0xD8 || (0xD0..=0xD7).contains(&marker) || marker == 0x01 {
            i += 2;
            continue;
        }
        if marker == 0xDA || marker == 0xD9 {
            break;
        }
        let len = u16::from_be_bytes([b[i + 2], b[i + 3]]) as usize;
        if len < 2 || i + 2 + len > b.len() {
            break;
        }
        let seg = &b[i + 4..i + 2 + len];
        match marker {
            0xE0 if seg.len() >= 12 && seg.starts_with(b"JFIF\0") => {
                let unit = seg[7];
                let x = u16::from_be_bytes([seg[8], seg[9]]) as f32;
                let y = u16::from_be_bytes([seg[10], seg[11]]) as f32;
                if x > 0.0 && y > 0.0 {
                    jfif_dpi = match unit {
                        1 => Some((x, y)),
                        2 => Some((x * 2.54, y * 2.54)),
                        _ => None,
                    };
                }
            }
            0xE1 if seg.starts_with(EXIF_HEADER) && m.exif.is_none() => {
                m.exif = Some(seg[EXIF_HEADER.len()..].to_vec());
            }
            0xE1 if seg.starts_with(XMP_HEADER) && m.xmp.is_none() => {
                m.xmp = std::str::from_utf8(&seg[XMP_HEADER.len()..]).ok().map(|s| s.trim_end_matches('\0').to_owned());
            }
            0xED if seg.starts_with(PHOTOSHOP_HEADER) && photoshop.len() < 1 << 24 => {
                photoshop.extend_from_slice(&seg[PHOTOSHOP_HEADER.len()..]);
            }
            0xE2 if seg.len() >= 14 && seg.starts_with(ICC_HEADER) => {
                icc_parts.push((seg[12], seg[13], &seg[14..]));
            }
            0xC0..=0xCF if !matches!(marker, 0xC4 | 0xC8 | 0xCC) && seg.len() >= 6 && m.frame.is_none() => {
                let h = u16::from_be_bytes([seg[1], seg[2]]) as u32;
                let w = u16::from_be_bytes([seg[3], seg[4]]) as u32;
                m.frame = Some((w, h, seg[5]));
            }
            0xEE if seg.len() >= 12 && seg.starts_with(b"Adobe") => {
                m.adobe_transform = Some(seg[11]);
            }
            _ => {}
        }
        i += 2 + len;
    }
    m.dpi = photoshop_resolution(&photoshop)
        .or_else(|| m.xmp.as_deref().and_then(xmp_resolution))
        .or_else(|| m.exif.as_deref().and_then(exif_resolution))
        .or(jfif_dpi);
    m.photoshop = Some(photoshop).filter(|p| !p.is_empty());
    if !icc_parts.is_empty() {
        icc_parts.sort_by_key(|p| p.0);
        let total = icc_parts[0].1 as usize;
        let seqs_ok = icc_parts.len() == total && icc_parts.iter().enumerate().all(|(k, p)| p.0 as usize == k + 1 && p.1 as usize == total);
        if seqs_ok || icc_parts.len() == 1 {
            m.icc = Some(icc_parts.iter().flat_map(|p| p.2.iter().copied()).collect());
        }
    }
    m
}

/// How a JPEG's data ends, seen from its marker structure.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DataEnd {
    /// An end-of-image marker follows the scans (or the structure is too odd to tell).
    Complete,
    /// The file ends inside the image data, before the end-of-image marker.
    Truncated,
    /// The file ends before the first scan holds any data: nothing can be decoded.
    Empty,
}

/// Walks the marker segments (skipped by their length) and the entropy-coded scan data
/// (skipped up to the next marker that isn't a stuffed `FF 00`, a restart or a fill byte),
/// so an embedded thumbnail's end marker or data after the end of the image don't count.
/// Also returns how many scan-data bytes the walk crossed: the truncated-input budget is
/// measured on these, not on the file length, which APP padding can inflate without
/// adding image data.
fn data_end(b: &[u8]) -> (DataEnd, u64) {
    // Where the bytes run out: inside the image data once a scan has held some.
    let cut = |scan_data: bool, scanned: u64| (if scan_data { DataEnd::Truncated } else { DataEnd::Empty }, scanned);
    let mut i = 2; // past SOI
    let mut scan_data = false;
    let mut scanned = 0u64;
    loop {
        let Some(&byte) = b.get(i) else { return cut(scan_data, scanned) };
        if byte != 0xFF {
            // Not where a marker should be: too odd to judge.
            return (DataEnd::Complete, scanned);
        }
        let Some(&code) = b.get(i + 1) else { return cut(scan_data, scanned) };
        match code {
            0xD9 => return (DataEnd::Complete, scanned),
            0xFF => i += 1,
            0x01 | 0xD0..=0xD8 => i += 2,
            _ => {
                let Some(len) = b.get(i + 2..i + 4).and_then(|s| <[u8; 2]>::try_from(s).ok()).map(u16::from_be_bytes) else {
                    return cut(scan_data, scanned);
                };
                i = i.saturating_add(2 + usize::from(len));
                if code == 0xDA {
                    let start = i;
                    loop {
                        let Some(p) = b.get(i..).and_then(|r| r.iter().position(|&v| v == 0xFF)) else {
                            // EOF inside this scan: everything from the scan start to the end
                            // of the file is scan data (inside a declared segment it may not
                            // be, so only count what remains).
                            return cut(scan_data || b.len() > start, scanned + u64::try_from(b.len().saturating_sub(start)).unwrap_or(0));
                        };
                        i += p;
                        match b.get(i + 1) {
                            Some(0x00 | 0xD0..=0xD7) => i += 2,
                            Some(0xFF) => i += 1,
                            _ => break,
                        }
                    }
                    scan_data |= i > start;
                    scanned += u64::try_from(i - start).unwrap_or(0);
                }
            }
        }
    }
}

fn err(e: impl std::fmt::Display) -> CodecError {
    CodecError::malformed(F, e)
}

/// Most pixels one byte of truncated scan data may account for. Even a flat image costs a few
/// bits per 8×8 block, and truncated photographs are far above this.
const MAX_TRUNCATED_PIXELS_PER_BYTE: u64 = 2048;

pub(crate) fn decode(bytes: &[u8], limits: &Limits) -> Result<Image, CodecError> {
    let (end, scan_bytes) = data_end(bytes);
    if end == DataEnd::Empty {
        return Err(err("the file ends before any image data"));
    }
    let meta = scan_metadata(bytes);
    if let Some((w, h, nc)) = meta.frame {
        limits.check_bytes(w, h, u64::from(nc.max(1)))?;
    }
    let options = DecoderOptions::default().set_strict_mode(false).set_max_width(65535).set_max_height(65535);
    let mut dec = zune_jpeg::JpegDecoder::new_with_options(ZCursor::new(bytes), options);
    dec.decode_headers().map_err(err)?;
    let (w, h) = dec.dimensions().ok_or_else(|| err("no dimensions"))?;
    let (w, h) = (w as u32, h as u32);
    let input = dec.input_colorspace().ok_or_else(|| err("no colorspace"))?;
    let (out_cs, layout) = match input {
        ColorSpace::Luma | ColorSpace::LumaA => (ColorSpace::Luma, ChannelLayout::Gray),
        ColorSpace::CMYK => (ColorSpace::CMYK, ChannelLayout::Cmyk),
        ColorSpace::YCCK => (ColorSpace::YCCK, ChannelLayout::Cmyk),
        _ => (ColorSpace::RGB, ChannelLayout::Rgb),
    };
    limits.check(w, h, layout, SampleType::U8)?;
    // The backend fills whatever the scan no longer describes, so a short scan under a large
    // frame is a gigabyte of synthesized output from a few kilobytes of file. The budget is
    // measured on the scan data itself: APP padding can inflate `bytes.len()` arbitrarily
    // without describing one more pixel.
    if end == DataEnd::Truncated && u64::from(w) * u64::from(h) / MAX_TRUNCATED_PIXELS_PER_BYTE > scan_bytes {
        return Err(err("the truncated scan is too short for the frame it declares"));
    }
    dec.set_options(dec.options().jpeg_set_out_colorspace(out_cs));
    let mut px = dec.decode().map_err(err)?;
    let expected = w as usize * h as usize * layout.channels();
    if px.len() < expected {
        return Err(err("short pixel buffer"));
    }
    px.truncate(expected);
    match input {
        // Adobe-style CMYK is stored inverted (255 = no ink).
        ColorSpace::CMYK => px.iter_mut().for_each(|v| *v = 255 - *v),
        ColorSpace::YCCK => {
            for p in px.as_chunks_mut::<4>().0 {
                let (y, cb, cr) = (p[0] as f32, p[1] as f32 - 128.0, p[2] as f32 - 128.0);
                let c = y + 1.402 * cr;
                let m = y - 0.344_136 * cb - 0.714_136 * cr;
                let yy = y + 1.772 * cb;
                p[0] = c.round().clamp(0.0, 255.0) as u8;
                p[1] = m.round().clamp(0.0, 255.0) as u8;
                p[2] = yy.round().clamp(0.0, 255.0) as u8;
                p[3] = 255 - p[3];
            }
        }
        _ => {}
    }
    let mut img = Image::from_raw(w, h, layout, SampleType::U8, px)?;
    img.icc = meta.icc;
    img.meta = Metadata { exif: meta.exif, xmp: meta.xmp, dpi: meta.dpi, photoshop_resources: meta.photoshop, ..Default::default() };
    if end == DataEnd::Truncated {
        img.warnings.push(DecodeWarning::Truncated { format: F });
    }
    Ok(img)
}

pub(crate) fn encode(src: &Image, plan: Plan, opts: &EncodeOptions) -> Result<Vec<u8>, CodecError> {
    let img = src.converted(plan.layout, plan.sample);
    let (w, h) = img.dimensions();
    let (w16, h16) = match (u16::try_from(w), u16::try_from(h)) {
        (Ok(a), Ok(b)) => (a, b),
        _ => {
            return Err(CodecError::encode(F, "JPEG dimensions are limited to 65535"));
        }
    };
    let ct = match img.layout() {
        ChannelLayout::Gray => jpeg_encoder::ColorType::Luma,
        ChannelLayout::Rgb => jpeg_encoder::ColorType::Rgb,
        ChannelLayout::Cmyk => jpeg_encoder::ColorType::Cmyk,
        l => return Err(CodecError::encode(F, format!("unsupported layout {l:?}"))),
    };
    let mut out = Vec::new();
    let mut enc = jpeg_encoder::Encoder::new(&mut out, opts.jpeg_quality.clamp(1, 100));
    // CMYK is always written 4:4:4: subsampled 4-component JPEGs are not
    // decoded consistently across implementations.
    let subsampled = opts.jpeg_chroma_subsampling && img.layout() == ChannelLayout::Rgb;
    let sampling = if subsampled { jpeg_encoder::SamplingFactor::R_4_2_0 } else { jpeg_encoder::SamplingFactor::R_4_4_4 };
    enc.set_sampling_factor(sampling);
    // JPEG Options › Format Options. Fitted Huffman tables make a baseline scan non-interleaved
    // (one scan per component), which zune-jpeg 0.5.15 decodes wrongly with 4:2:0 chroma
    // (etemesi254/zune-image#419; see `web::encode_jpeg_rgb8`), so a subsampled Baseline
    // Optimized keeps the standard tables until that decoder is updated. Progressive is fine.
    let progressive = opts.jpeg_format == JpegFormat::Progressive;
    enc.set_progressive(progressive);
    let optimized = opts.jpeg_format == JpegFormat::Optimized && !subsampled;
    enc.set_optimized_huffman_tables(progressive || optimized);
    let e = |e: jpeg_encoder::EncodingError| CodecError::encode(F, e);
    if opts.embed_metadata {
        if img.layout() != ChannelLayout::Cmyk
            && let Some((x, y)) = img.meta.dpi
            && x >= 1.0
            && y >= 1.0
        {
            enc.set_density(jpeg_encoder::Density::Inch { x: x.round().min(65535.0) as u16, y: y.round().min(65535.0) as u16 });
        }
        // Metadata too large for its one segment is left out (and reported by the fidelity
        // warnings) rather than failing the whole export.
        let exif = if img.layout() == ChannelLayout::Cmyk {
            match img.meta.exif.as_deref() {
                Some(exif) => exif_segment_with_resolution(exif, img.meta.dpi),
                None if usable_dpi(img.meta.dpi) => exif_segment_with_resolution(&[], img.meta.dpi),
                None => None,
            }
        } else {
            img.meta.exif.as_deref().and_then(|x| exif_segment(x, img.meta.dpi))
        };
        if let Some(seg) = exif {
            enc.add_app_segment(1, &seg).map_err(e)?;
        }
        if let Some(seg) = img.meta.xmp.as_deref().and_then(|x| xmp_segment(x, img.meta.dpi)) {
            enc.add_app_segment(1, &seg).map_err(e)?;
        }
    }
    if opts.embed_icc
        && let Some(icc) = &img.icc
    {
        enc.add_icc_profile(icc).map_err(e)?;
    }
    enc.encode(img.data(), w16, h16, ct).map_err(e)?;
    if img.layout() == ChannelLayout::Cmyk {
        strip_jfif_app0(&mut out);
    }
    Ok(out)
}

/// JFIF APP0 requires one or three image components. A four-component CMYK JPEG must not carry
/// that marker; keep Adobe APP14, which identifies the CMYK encoding instead.
fn strip_jfif_app0(bytes: &mut Vec<u8>) {
    if !bytes.starts_with(&[0xff, 0xd8]) {
        return;
    }
    let mut i = 2usize;
    loop {
        if bytes.get(i) != Some(&0xff) {
            return;
        }
        let Some(&marker) = bytes.get(i.saturating_add(1)) else { return };
        if matches!(marker, 0xda | 0xd9) {
            return;
        }
        if marker == 0xff {
            i = i.saturating_add(1);
            continue;
        }
        if marker == 0x01 || (0xd0..=0xd8).contains(&marker) {
            i = i.saturating_add(2);
            continue;
        }
        let Some(length_bytes) = i.checked_add(2).and_then(|at| bytes.get(at..at.checked_add(2)?)) else { return };
        let Ok(length_bytes) = <[u8; 2]>::try_from(length_bytes) else { return };
        let length = usize::from(u16::from_be_bytes(length_bytes));
        if length < 2 {
            return;
        }
        let Some(end) = i.checked_add(2).and_then(|at| at.checked_add(length)) else { return };
        if end > bytes.len() {
            return;
        }
        if marker == 0xe0 && bytes.get(i.saturating_add(4)..i.saturating_add(9)) == Some(b"JFIF\0") {
            bytes.drain(i..end);
        } else {
            i = end;
        }
    }
}

/// Return whether both resolution values are finite and within the supported metadata range.
fn usable_dpi(dpi: Option<(f32, f32)>) -> bool {
    dpi.is_some_and(|(x, y)| x.is_finite() && y.is_finite() && (1.0..=1_000_000.0).contains(&x) && (1.0..=1_000_000.0).contains(&y))
}

/// The most data one APP segment holds (its 16-bit length counts its own two bytes).
const MAX_SEGMENT: usize = 65533;

/// XMP properties (local names, any namespace prefix) that only describe the layered document:
/// every document ever placed in it, the text of every type layer. A flat image doesn't need them,
/// and they alone can outgrow a segment.
const LAYERED_ONLY_XMP: [&str; 2] = ["DocumentAncestors", "TextLayers"];

/// The EXIF APP1 segment, or `None` when it doesn't fit in one segment.
pub(crate) fn exif_segment(exif: &[u8], dpi: Option<(f32, f32)>) -> Option<Vec<u8>> {
    // The pixels are written as they are shown: never let a viewer rotate them again; and store
    // the output resolution, not the source's (#1691).
    let seg = [EXIF_HEADER, export_exif(exif, dpi).as_ref()].concat();
    (seg.len() <= MAX_SEGMENT).then_some(seg)
}

/// Build an EXIF APP1 segment, adding missing resolution tags when the source metadata is valid.
fn exif_segment_with_resolution(exif: &[u8], dpi: Option<(f32, f32)>) -> Option<Vec<u8>> {
    let seg = [EXIF_HEADER, crate::resolution::export_exif_adding_missing_resolution(exif, dpi).as_ref()].concat();
    (seg.len() <= MAX_SEGMENT).then_some(seg)
}

/// The XMP APP1 segment. When the packet doesn't fit in one segment, the layered-document
/// properties are left out; `None` when it still doesn't fit.
pub(crate) fn xmp_segment(xmp: &str, dpi: Option<(f32, f32)>) -> Option<Vec<u8>> {
    let xmp = export_xmp(xmp, dpi);
    let seg = |x: &str| [XMP_HEADER, x.as_bytes()].concat();
    if XMP_HEADER.len() + xmp.len() <= MAX_SEGMENT {
        return Some(seg(&xmp));
    }
    let trimmed = LAYERED_ONLY_XMP.iter().fold(xmp.into_owned(), |x, name| remove_element(&x, name));
    (XMP_HEADER.len() + trimmed.len() <= MAX_SEGMENT).then(|| seg(&trimmed))
}

/// `xmp` without its `<prefix:name …>…</prefix:name>` and `<prefix:name …/>` elements. Unbalanced
/// markup is kept as is.
fn remove_element(xmp: &str, name: &str) -> String {
    let local = format!(":{name}");
    let mut out = String::with_capacity(xmp.len());
    let mut rest = xmp;
    while let Some(j) = rest.find(&local) {
        let head = rest.get(..j).unwrap_or_default();
        let prefix_len = head.bytes().rev().take_while(|b| b.is_ascii_alphanumeric() || matches!(b, b'_' | b'-' | b'.')).count();
        let lt = j - prefix_len;
        let after = rest.get(j + local.len()..).unwrap_or_default();
        // An opening tag of exactly this name (not a closing tag, an attribute or a longer name).
        let opening = prefix_len > 0 && lt > 0 && rest.get(lt - 1..lt) == Some("<");
        if !opening || !after.starts_with(['>', '/', ' ', '\t', '\r', '\n']) {
            out.push_str(rest.get(..j + local.len()).unwrap_or_default());
            rest = after;
            continue;
        }
        let Some(gt) = after.find('>') else { break };
        let end = if after.get(..gt).is_some_and(|s| s.ends_with('/')) {
            gt + 1
        } else {
            let close = format!("</{}{local}>", rest.get(lt..j).unwrap_or_default());
            let Some(c) = after.find(&close) else { break };
            c + close.len()
        };
        out.push_str(rest.get(..lt - 1).unwrap_or_default());
        rest = after.get(end..).unwrap_or_default();
    }
    out.push_str(rest);
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Format, Metadata};

    /// Build a little-endian TIFF with an empty IFD0 for metadata tests.
    fn empty_tiff() -> Vec<u8> {
        // Little-endian TIFF with an empty IFD0 and no next IFD.
        b"II*\0\x08\0\0\0\0\0\0\0\0\0\0\0".to_vec()
    }

    /// Return whether the JPEG begins with a JFIF APP0 segment.
    fn has_jfif_app0(bytes: &[u8]) -> bool {
        bytes.get(2..11) == Some(b"\xff\xe0\0\x10JFIF\0")
    }

    /// A tiny truncated scan under a frame patched to 20000×20000 is refused before the backend
    /// fills 400 million pixels from it; the same file with its real size still recovers.
    #[test]
    fn a_short_truncated_scan_cannot_declare_a_huge_frame() {
        let img = Image::from_raw(16, 16, ChannelLayout::Rgb, SampleType::U8, vec![128; 16 * 16 * 3]).unwrap();
        let full = crate::encode(&img, Format::Jpeg, &EncodeOptions::default()).unwrap();
        let cut = &full[..full.len() - 4];
        assert_eq!(data_end(cut).0, DataEnd::Truncated);
        assert!(crate::decode_as(Format::Jpeg, cut).is_ok());
        let sof = cut.windows(2).position(|w| w == [0xFF, 0xC0] || w == [0xFF, 0xC2]).unwrap();
        let mut huge = cut.to_vec();
        huge[sof + 5..sof + 9].copy_from_slice(&[0x4E, 0x20, 0x4E, 0x20]);
        let e = crate::decode_as(Format::Jpeg, &huge).unwrap_err();
        assert!(e.to_string().contains("too short"), "{e}");
    }

    /// The truncated-scan budget counts scan data, not the file length: APP padding before the
    /// window cannot admit an oversized output. The same padded file with its real size still
    /// decodes (with the truncation warning).
    #[test]
    fn app_padding_cannot_admit_an_oversized_truncated_frame() {
        let img = Image::from_raw(16, 16, ChannelLayout::Rgb, SampleType::U8, vec![128; 16 * 16 * 3]).unwrap();
        let full = crate::encode(&img, Format::Jpeg, &EncodeOptions::default()).unwrap();
        let cut = &full[..full.len() - 4];
        // Four full-length COMMENT segments (~256 KiB) stand where APP padding would; they are
        // complete, so the file otherwise parses normally.
        let fill = [b'p'; 65533];
        let mut padded = cut[..2].to_vec();
        for _ in 0..4 {
            padded.extend_from_slice(&[0xFF, 0xFE]);
            padded.extend_from_slice(&0xFFFFu16.to_be_bytes());
            padded.extend_from_slice(&fill);
        }
        padded.extend_from_slice(&cut[2..]);
        assert_eq!(data_end(&padded).0, DataEnd::Truncated);
        // Well above the frame's pixels / budget, yet far above the scan data: the old
        // file-length bound admitted this frame.
        assert!(padded.len() > (u64::from(20_000u32) * u64::from(20_000u32) / MAX_TRUNCATED_PIXELS_PER_BYTE) as usize, "padding too small");
        assert!(crate::decode_as(Format::Jpeg, &padded).is_ok());
        let sof = padded.windows(2).position(|w| w == [0xFF, 0xC0] || w == [0xFF, 0xC2]).unwrap();
        let mut huge = padded.clone();
        huge[sof + 5..sof + 9].copy_from_slice(&[0x4E, 0x20, 0x4E, 0x20]);
        let e = crate::decode_as(Format::Jpeg, &huge).unwrap_err();
        assert!(e.to_string().contains("too short"), "{e}");
    }

    /// CMYK JPEG output must omit JFIF while retaining Adobe's CMYK marker.
    #[test]
    fn cmyk_jpeg_omits_jfif_but_keeps_adobe_cmyk_marker() {
        let img = Image::from_raw(2, 1, ChannelLayout::Cmyk, SampleType::U8, vec![0, 32, 64, 96, 255, 224, 192, 160]).unwrap();
        let bytes = crate::encode(&img, Format::Jpeg, &EncodeOptions::default()).unwrap();

        let meta = scan_metadata(&bytes);
        assert!(!has_jfif_app0(&bytes));
        assert_eq!(meta.frame, Some((2, 1, 4)));
        assert_eq!(meta.adobe_transform, Some(0));
        assert_eq!(crate::decode_as(Format::Jpeg, &bytes).unwrap().layout(), ChannelLayout::Cmyk);
    }

    /// CMYK JPEG output stores image resolution in EXIF when the source has no EXIF.
    #[test]
    fn cmyk_jpeg_preserves_dpi_without_source_exif() {
        let mut img = Image::from_raw(1, 1, ChannelLayout::Cmyk, SampleType::U8, vec![0, 0, 0, 0]).unwrap();
        img.meta.dpi = Some((300.0, 150.0));
        let bytes = crate::encode(&img, Format::Jpeg, &EncodeOptions::default()).unwrap();

        assert!(!has_jfif_app0(&bytes));
        assert_eq!(crate::decode_as(Format::Jpeg, &bytes).unwrap().meta.dpi, Some((300.0, 150.0)));
    }

    /// CMYK JPEG output adds missing EXIF resolution tags to existing metadata.
    #[test]
    fn cmyk_jpeg_preserves_dpi_with_source_exif_without_resolution_tags() {
        let mut img = Image::from_raw(1, 1, ChannelLayout::Cmyk, SampleType::U8, vec![0, 0, 0, 0]).unwrap();
        img.meta = Metadata { exif: Some(empty_tiff()), dpi: Some((240.0, 120.0)), ..Default::default() };
        let bytes = crate::encode(&img, Format::Jpeg, &EncodeOptions::default()).unwrap();

        assert_eq!(crate::decode_as(Format::Jpeg, &bytes).unwrap().meta.dpi, Some((240.0, 120.0)));
    }

    /// Adding missing resolution tags makes them readable from the rewritten IFD0.
    #[test]
    fn exif_with_resolution_adds_missing_ifd0_entries() {
        let exif = empty_tiff();
        let rewritten = crate::resolution::export_exif_adding_missing_resolution(&exif, Some((240.0, 120.0)));

        assert_eq!(crate::resolution::exif_resolution(&rewritten), Some((240.0, 120.0)));
    }

    /// RGB JPEG output continues to store image resolution in JFIF density fields.
    #[test]
    fn rgb_jpeg_keeps_jfif_density() {
        let mut img = Image::from_raw(1, 1, ChannelLayout::Rgb, SampleType::U8, vec![12, 34, 56]).unwrap();
        img.meta.dpi = Some((96.0, 96.0));
        let bytes = crate::encode(&img, Format::Jpeg, &EncodeOptions::default()).unwrap();

        assert!(has_jfif_app0(&bytes));
        assert_eq!(scan_metadata(&bytes).dpi, Some((96.0, 96.0)));
    }
}
